# The Kart Racing Chicken Collector
 A Unity Game created by me with the main objective is to collect all the chickens whether they are flying or not, as it will increase your score. The game is not the best, and it is not 100% original. I at least made the chicken model in Blender which is a 3d model program.

Also, it is an improvement than hosting it on Codepen, which is painful.

To play the game, it's easy, I hosted it on this url:

https://justincodingprojects.github.io/The-Kart-Racing-Chicken-Collector/
